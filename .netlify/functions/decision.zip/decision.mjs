
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/decision.mjs
var RATE_LIMIT = 10;
var RATE_WINDOW_MS = 60 * 60 * 1e3;
var MAX_CONVERSATION_MESSAGES = 12;
var ipRequests = /* @__PURE__ */ new Map();
function isRateLimited(ip) {
  const now = Date.now();
  const requests = ipRequests.get(ip) || [];
  const recent = requests.filter((t) => now - t < RATE_WINDOW_MS);
  if (recent.length >= RATE_LIMIT) return true;
  recent.push(now);
  ipRequests.set(ip, recent);
  return false;
}
var decision_default = async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, {
      status: 204,
      headers: {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Methods": "POST, OPTIONS",
        "Access-Control-Allow-Headers": "Content-Type"
      }
    });
  }
  if (req.method !== "POST") {
    return Response.json({ error: "Method not allowed" }, { status: 405 });
  }
  const apiKey = process.env.ANTHROPIC_API_KEY;
  if (!apiKey) {
    return Response.json({ error: "Server configuration error" }, { status: 500 });
  }
  const ip = req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || "unknown";
  if (isRateLimited(ip)) {
    return Response.json({ error: "Limite de pedidos atingido. Tenta novamente mais tarde." }, { status: 429 });
  }
  try {
    const body = await req.json();
    const messages = body.messages;
    if (!Array.isArray(messages) || messages.length === 0) {
      return Response.json({ error: "Messages array required" }, { status: 400 });
    }
    const truncated = messages.slice(-MAX_CONVERSATION_MESSAGES);
    const response = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": apiKey,
        "anthropic-version": "2023-06-01"
      },
      body: JSON.stringify({
        model: "claude-sonnet-4-20250514",
        max_tokens: 1500,
        messages: truncated
      })
    });
    if (!response.ok) {
      const err = await response.text();
      console.error("Anthropic API error:", response.status, err);
      return Response.json(
        { error: "Erro na API: " + response.status },
        {
          status: response.status === 429 ? 429 : 502,
          headers: { "Access-Control-Allow-Origin": "*" }
        }
      );
    }
    const data = await response.json();
    return Response.json(data, {
      headers: { "Access-Control-Allow-Origin": "*" }
    });
  } catch (err) {
    console.error("Function error:", err);
    return Response.json({ error: "Erro interno do servidor" }, { status: 500 });
  }
};
var config = {
  path: "/api/decision"
};
export {
  config,
  decision_default as default
};
